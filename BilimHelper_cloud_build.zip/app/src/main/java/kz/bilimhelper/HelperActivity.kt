package kz.bilimhelper

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class HelperActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val input = EditText(this).apply { hint = "Вставь текст задания сюда"; minLines = 4; gravity = Gravity.TOP }
        val result = TextView(this).apply { text = "Здесь появится разбор задания."; textSize = 16f }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24)
            addView(TextView(this@HelperActivity).apply { text = "Помощник BilimClass"; textSize = 22f })
            addView(input)
            addView(Button(this@HelperActivity).apply {
                text = "Подготовить задание"
                setOnClickListener { result.text = if (input.text.isNullOrBlank()) "Сначала вставь текст задания." else "Текст принят. ИИ-распознавание пока не подключено — это стартовая версия." }
            })
            addView(result)
            addView(Button(this@HelperActivity).apply { text = "Закрыть"; setOnClickListener { finish() } })
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
